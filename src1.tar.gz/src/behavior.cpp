
#include "behavior.h"

/*
The last consideration is how to create paths that can smoothly changes lanes. Any time the ego vehicle approaches a car in front of it that is moving slower than the speed limit, the ego vehicle should consider changing lanes.

The car should only change lanes if such a change would be safe, and also if the lane change would help it move through the flow of traffic better.

For safety, a lane change path should optimize the distance away from other traffic. For comfort, a lane change path should also result in low acceleration and jerk. The acceleration and jerk part can be solved from linear equations for s and d functions. Examples of this can be found in the Trajectory Generation quizzes entitled, "Quintic Polynomial Solver" and "Polynomial Trajectory".
*/



Behavior::Behavior() {
  current_lane = 1;
  state = 1;
}

bool Behavior::is_middle_lane(const double& d) {
  return ( (d > LANE_WIDTH) && ( d < LANE_WIDTH * 2) );
}

bool Behavior::is_left_lane(const double& d) {
  return ( (d >= 0.0) && ( d <= LANE_WIDTH) );
}

bool Behavior::is_right_lane(const double& d) {
  return ( (d >= LANE_WIDTH * 2) && ( d <= LANE_WIDTH * 3) );
}

// input: Sensor Fusion Data, a list of all other cars on the same side of the road.
void Behavior::sense_traffic(const json &sensor_fusion, double car_s) {

  int num_cars = sensor_fusion.size();

  // TODO: rewrite this whole loop

  // finding closest cars in all 3 lanes, one in front and one in back

  // 1. get closest car id's by comparing s
  double min_dist = 99999;
  double min_sens_i;

  double min_s_front_left = 99999;
  double min_s_front_center = 99999;
  double min_s_front_right = 99999;

  double max_s_back_left = -99999;
  double max_s_back_center = -99999;
  double max_s_back_right = -99999;

  printf("\n XX1 \n");

  // finding closest cars in all 3 lanes, one in front and one in back
  for (int i = 0; i < num_cars; ++i)
  {
    auto sens = sensor_fusion[i];
    double sens_id = sens[0];
    double sens_x = sens[1];
    double sens_y = sens[2];
    double sens_vel_x = sens[3];
    double sens_vel_y = sens[4];
    double sens_s = sens[5];
    double sens_d = sens[6];
    double sens_vel = sqrt(sens_vel_x*sens_vel_x + sens_vel_y*sens_vel_y);
    double s_dist = sens_s - car_s;  //  front: 10 - 5; 12 - 5  .. want min value  distance(car_x,car_y,sens_x,sens_y);
                                     //  back:  3  - 5; 1  - 5  .. want max value

    printf("\n XX2 sens_id = %f, sens_s = %f, sens_d = %f \n", sens_id, sens_s, sens_d);


    if( is_middle_lane(sens_d) ) // middle lane
    {
      if (sens_s > car_s) // car in front (center)
      {
        if (s_dist < min_s_front_center)
        {
          min_s_front_center = s_dist;
          traffic ctr_ahead = traffic( sensor_fusion, i );
          surrounding_traffic[CTR_AHREAD] = ctr_ahead;
        }
      }
      else // car behind (center)
      {
        if (s_dist > max_s_back_center)
        {
          max_s_back_center = s_dist;
          traffic ctr_behind = traffic( sensor_fusion, i );
          surrounding_traffic[CTR_BEHIND] = ctr_behind;
        }
      }
    }
    else if( is_left_lane(sens_d) ) { // car in left lane
      if (sens_s > car_s) // car in front (left)
      {
        if (s_dist < min_s_front_left) // find closest car in front
        {
          min_s_front_left = s_dist;
          traffic left_ahead = traffic( sensor_fusion, i );
          surrounding_traffic[LEFT_AHEAD] = left_ahead;
        }
      }
      else // car behind (left)
      {
        if (s_dist > max_s_back_left)
        {
          max_s_back_left = s_dist;
          traffic left_behind = traffic( sensor_fusion, i );
          surrounding_traffic[LEFT_BEHIND] = left_behind;
        }
      }
    }
    else if( is_right_lane(sens_d) ) {
      if (sens_s > car_s) // car in front (right)
      {
        if (s_dist < min_s_front_right) // find closest car in front
        {
          min_s_front_right = s_dist;
          traffic right_ahead = traffic( sensor_fusion, i );
          surrounding_traffic[RIGHT_AHREAD] = right_ahead;
        }
      }
      else // car behind (right)
      {
        if (s_dist > max_s_back_right) // find closest car in front
        {
          max_s_back_right = s_dist;
          traffic right_behind = traffic( sensor_fusion, i );
          surrounding_traffic[RIGHT_BEHIND] = right_behind;
        }
      }
    }
  }

  print_surrounding_traffic();
}

void Behavior::print_surrounding_traffic() {
  int label_value = 1;
  printf("\n Surrounding Traffic: \n");
  for( auto label_it = traffic_labels.begin(); label_it != traffic_labels.end(); ++label_it, ++label_value ) {
    auto found_label_it = surrounding_traffic.find( label_value );
    if( found_label_it != surrounding_traffic.end() ) {
      printf("  %s: ", label_it->c_str());
      surrounding_traffic[label_value].print();
    }
  }
  printf("\n");
}

void Behavior::update_state(const std::vector<double>& previous_path_x,
                            const std::vector<double>& previous_path_y) {

  // 1. ignore N values from previous path and keep the rest

  // 2. use the size-N'th value as current car position

  if( previous_path_x.size() == 0 )
    return;


}
