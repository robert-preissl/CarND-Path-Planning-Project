
#include "trajectory.h"

// For converting back and forth between radians and degrees.
double deg2rad(double x) { return x * pi() / 180; }
double rad2deg(double x) { return x * 180 / pi(); }

double distance(double x1, double y1, double x2, double y2)
{
	return sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
}

void Trajectory::calculate_path(const traffic& own_car,
                                const std::vector<double>& previous_path_x,
                                const std::vector<double>& previous_path_y,
                                std::vector<double>& next_x_vals,
                                std::vector<double>& next_y_vals) {

  double targ_d = 6.0; // TODO: needs to come from behavior

  int path_size = previous_path_x.size();

  // Copy old path
  // TODO: what if path_size == 50 ??
  for(int i = 0; i < path_size; i++)
  {
    next_x_vals.push_back(previous_path_x[i]);
    next_y_vals.push_back(previous_path_y[i]);
  }

  // TODO: is pos_x != car_x ??

  double pos_x, pos_y, angle, pos_d, pos_s, end_path_d, speed, prev_s, prev_d;

  // Initialize path to current position if no path
  if(path_size == 0)
  {
    pos_x = own_car.x;
    pos_y = own_car.y;
    angle = deg2rad(own_car.yaw);
    pos_s = own_car.s;
    pos_d = own_car.d;
    end_path_d = own_car.d;
    speed = own_car.vel;
    prev_s = own_car.s;
    prev_d = own_car.d;
  }
  else // Calculate angle and get position from previous data
  {
    pos_x = previous_path_x[path_size-1];
    pos_y = previous_path_y[path_size-1];

    double pos_x2 = previous_path_x[path_size-2];
    double pos_y2 = previous_path_y[path_size-2];
    angle = atan2(pos_y-pos_y2,pos_x-pos_x2);

    double delta_x = pos_x2-pos_x;
    double delta_y = pos_y2-pos_y;
    speed = distance(pos_x, pos_y, pos_x2, pos_y2) / 0.02;
  }
  // we have targ_d and targ_dist_inc to the target in optimistic case

  double d_smoothing_steps = 50; // TODO: Calculate parameter based
  double delta = (targ_d - end_path_d) / d_smoothing_steps;

  // Setup path waypoints
  double path_point_x;
  double path_point_y;
  double path_point_dx;
  double path_point_dy;

/*
  // Create path for lane change
  if (plan_lane_change)
  {
    // take last position and last position -10
    // take target position and target position +10
    // create spline
    vector<double> line_change_s;
    vector<double> line_change_d;
    line_change_s.push_back(pos_s-4);
    line_change_d.push_back(prev_d);
    line_change_s.push_back(pos_s-3);
    line_change_d.push_back(prev_d);
    line_change_s.push_back(pos_s-2);
    line_change_d.push_back(prev_d);
    line_change_s.push_back(pos_s-1);
    line_change_d.push_back(prev_d);
    line_change_s.push_back(pos_s);
    line_change_d.push_back(prev_d);

    line_change_s.push_back(pos_s+50);
    line_change_d.push_back(targ_d);
    line_change_s.push_back(pos_s+54);
    line_change_d.push_back(targ_d);

    tk::spline path_d;
    path_d.set_points(line_change_s, line_change_d);


    for(int i = 0; i < 50; i++)
    {
      double delta_prev_s = pos_s - prev_s;
      //double delta_prev_d = pos_d - prev_d;
      prev_s = pos_s;
      //prev_d = pos_d;
      pos_s += min(targ_dist_inc, (delta_prev_s*(1+0.005)+0.001));
      pos_s = fmod(pos_s, max_s);
      pos_d = path_d(pos_s);
      path_point_x = waypoints_x(pos_s);
      path_point_y = waypoints_y(pos_s);
      path_point_dx = waypoints_dx(pos_s);
      path_point_dy =  waypoints_dy(pos_s);
      //double lane_d = pp.d;

      pos_x = path_point_x + path_point_dx * pos_d;
      pos_y = path_point_y + path_point_dy * pos_d;

      next_x_vals.push_back(pos_x);
      next_y_vals.push_back(pos_y);
    }
    plan_lane_change = false;
  }

  */



// for map waypoints

/* RP
  map_data["x"] = map_waypoints_x;
  map_data["y"] = map_waypoints_y;
  map_data["s"] = map_waypoints_s;
  map_data["dx"] = map_waypoints_dx;
  map_data["dy"] = map_waypoints_dy;
*/

/* VAL
// correct spline calculation at the end of track
map_waypoints_x.push_back(map_waypoints_x[0]);
map_waypoints_y.push_back(map_waypoints_y[0]);
map_waypoints_s.push_back(max_s+map_waypoints_s[0]);
map_waypoints_dx.push_back(map_waypoints_dx[0]);
map_waypoints_dy.push_back(map_waypoints_dy[0]);

map_waypoints_x.push_back(map_waypoints_x[1]);
map_waypoints_y.push_back(map_waypoints_y[1]);
map_waypoints_s.push_back(max_s+map_waypoints_s[1]);
map_waypoints_dx.push_back(map_waypoints_dx[1]);
map_waypoints_dy.push_back(map_waypoints_dy[1]);

printf("\n AA2 \n");

// compute splines with "x" for x,y,dx,dy
tk::spline waypoints_x;
waypoints_x.set_points(map_waypoints_s, map_waypoints_x);

tk::spline waypoints_y;
waypoints_y.set_points(map_waypoints_s, map_waypoints_y);

tk::spline waypoints_dx;
waypoints_dx.set_points(map_waypoints_s, map_waypoints_dx);

tk::spline waypoints_dy;
waypoints_dy.set_points(map_waypoints_s, map_waypoints_dy);
*/


  // rewrite for loop for lane change
  if (path_size<50)
  {
    for(int i = 0; i < 50-path_size; i++)
    {
      double delta_prev_s = pos_s - prev_s;
      double delta_prev_d = pos_d - prev_d;
      prev_s = pos_s;
      prev_d = pos_d;

      // TODO
      //double pred_speed_to_car = in_front_dist/(50*dist_inc)+(in_front_vel/100-speed/100);
      //double targ_dist_inc = fmin(1.0, pred_speed_to_car)*dist_inc;

      double targ_dist_inc = dist_inc; // TODO:

      pos_s += fmin(targ_dist_inc, (delta_prev_s*(1+0.005)+0.001));
      pos_s = fmod(pos_s, max_s);

      if (delta>0.0)
      {
        pos_d += fmin(delta, 0.05);
      }
      else
      {
        pos_d += fmax(delta, -0.05);
      }

      // if (remaining_trajectory<1)
      // {
      //   if (delta>0.0)
      //   {
      //     pos_d += min(delta, 0.05);
      //   }
      //   else
      //   {
      //     pos_d += max(delta, -0.05);
      //   }
      // }
      // else
      // {
      //   double t = 50-remaining_trajectory;
      //   pos_d = jmt0 + jmt1*t + jmt2*t*t + jmt3*t*t*t + jmt4*t*t*t*t + jmt5*t*t*t*t*t;
      //   remaining_trajectory -= 1;
      //   cout << "Coef pos_d: " << pos_d << endl;
      // }

      path_point_x = waypoints_x(pos_s);
      path_point_y = waypoints_y(pos_s);
      path_point_dx = waypoints_dx(pos_s);
      path_point_dy =  waypoints_dy(pos_s);

      pos_x = path_point_x + path_point_dx * pos_d;
      pos_y = path_point_y + path_point_dy * pos_d;

      printf("\n WW1 -- pos_x = %f, pos_y = %f ", pos_x, pos_y)

      next_x_vals.push_back(pos_x);
      next_y_vals.push_back(pos_y);

    } // end for loop
  } // end if (path_size<50)


}
