
#ifndef TRAJECTORY_H
#define TRAJECTORY_H

#include <unordered_map>
#include <string.h>
#include <vector>

#include "behavior.h"
#include <math.h>

constexpr double pi() { return M_PI; }

double deg2rad(double x);
double rad2deg(double x);

double distance(double x1, double y1, double x2, double y2);

// TODO
const double dist_inc = 0.41; // max speed
const double max_s = 6945.554;

class Trajectory {

  private:
    std::unordered_map< std::string, std::vector<double> > map_data;

  public:
    Trajectory() {}
    Trajectory(std::unordered_map< std::string, std::vector<double> > map_data_) : map_data(map_data_) {}

    void calculate_path(const traffic& own_car,
                        const std::vector<double>& previous_path_x,
                        const std::vector<double>& previous_path_y,
                        std::vector<double>& next_x_vals,
                        std::vector<double>& next_y_vals);

};








#endif // TRAJECTORY_H
