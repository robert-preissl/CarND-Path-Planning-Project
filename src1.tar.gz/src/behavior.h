
/*
I have compiled a short summary of things I struggled with so far and I would've benefited of knowing when starting the project. I hope someone who starts the project just now will find it useful:

- read carefully both the `README.md` and the project description - they don't have the same information
 - `previous_path_x` and `previous_path_y` are always the future `n` steps of your car, i.e. they don't include `x` and `y`
- your car's `x` and `y` are always one of the points you've sent to the simulator in the previous cycle
 - some of the other cars don't appear immediately on the road and will have strange coordinates, e.g. `d = -200`
- the provided coordinate conversion functions are not smooth at all and you need to make your own
 - you can use `spline` for `Frenet` -> `Cartesian` XY conversion, where you fit `x` and `y` to `s`
- your conversion will never be completely accurate (expect displacements of 0 to 0.5 per axis, 0.1 on average)
 - always be careful when handling `s` - remember that the track is a circuit and `s` values around `0` and `6945.554` are fiddly to work with
- `Cartesian` XY -> `Frenet` is very inaccurate and complicated to improve, also not very useful
 - the time between two cycles is ~2-3 steps, i.e. `0.04s-0.06s`
- it is very useful to always include >3 previous path values to your next values for avoiding crazy behaviour of your car
 - generate your trajectory from your car's position in a couple of steps from now (maybe 10?)
 - when getting your car coordinates, don't rely on the provided `s`, `d` or `speed`
- keep your previous trajectory in `Frenet` and `Cartesian` and use it for calculating `s`, `d`, `s_dot` and `d_dot` from your car's `x` and `y` from the simulator
 - all cars are roughly ~5m long - use that knowledge for calculating buffer distance
 */


#ifndef BEHAVIOR_H
#define BEHAVIOR_H

#include <unordered_map>
#include <string.h>
#include <vector>

#include "json.hpp"
using json = nlohmann::json;

// states
#define STATE_KL  1 // keep lane state
#define STATE_LC  2 // lane change state
#define STATE_PLC 3 // prepare for lane change state


struct traffic {
  double id;
  double x;
  double y;
  double vel_x;
  double vel_y;
  double vel;
  double s;
  double d;
  double yaw;

  traffic() {}

  traffic(double id_, double x_, double y_, double vel_x_, double vel_y_, double s_, double d_, double yaw_) :
           id(id_), x(x_), y(y_), vel_x(vel_x_), vel_y(vel_y_), s(s_), d(d_), yaw(yaw_) { vel = sqrt(vel_x*vel_x + vel_y*vel_y); }

  traffic(double id_, double x_, double y_, double vel_, double s_, double d_ , double yaw_) :
           id(id_), x(x_), y(y_), vel(vel_), s(s_), d(d_), yaw(yaw_) { vel_x = 0.0; vel_y = 0.0; }

  traffic(const json &sensor_fusion, int json_index) {
    auto sens = sensor_fusion[json_index];
    id = sens[0];
    x = sens[1];
    y = sens[2];
    vel_x = sens[3];
    vel_y = sens[4];
    vel = sqrt(vel_x*vel_x + vel_y*vel_y);
    s = sens[5];
    d = sens[6];
  }

  void print() {
    printf( "Car Id: %f => x: %f, y: %f, vel_x: %f, vel_y: %f, vel: %f, s: %f, d: %f \n",
             id, x, y, vel_x, vel_y, vel, s, s);
  }

};

#define LEFT_BEHIND  1 // TODO: change names to front, back?? what does uda do?
#define LEFT_AHEAD   2
#define CTR_BEHIND   3
#define CTR_AHREAD   4
#define RIGHT_BEHIND 5
#define RIGHT_AHREAD 6

const std::vector<std::string> traffic_labels = {"LEFT_BEHIND", "LEFT_AHEAD", "CTR_BEHIND", "CTR_AHREAD", "RIGHT_BEHIND", "RIGHT_AHREAD"};

const int LANE_WIDTH = 4;

class Behavior {

  private:
    int state;
    int current_lane;

    std::unordered_map<int, traffic> surrounding_traffic;
    void print_surrounding_traffic();

  public:
    Behavior();

    void sense_traffic(const json &sensor_fusion, double car_s);

    void clear_surrounding_traffic() {
      surrounding_traffic.clear();
    }

    void update_state(const std::vector<double>& previous_path_x,
                      const std::vector<double>& previous_path_y);

    bool is_middle_lane(const double& d);

    bool is_left_lane(const double& d);

    bool is_right_lane(const double& d);

};


#endif // BEHAVIOR_H




#ifdef AA
def transition_function(predictions, current_fsm_state, current_pose, cost_functions, weights):
    # only consider states which can be reached from current FSM state.
    possible_successor_states = successor_states(current_fsm_state)

    # keep track of the total cost of each state.
    costs = []
    for state in possible_successor_states:
        # generate a rough idea of what trajectory we would
        # follow IF we chose this state.
        trajectory_for_state = generate_trajectory(state, current_pose, predictions)

        # calculate the "cost" associated with that trajectory.
        cost_for_state = 0
        for i in range(len(cost_functions)) :
            # apply each cost function to the generated trajectory
            cost_function = cost_functions[i]
            cost_for_cost_function = cost_function(trajectory_for_state, predictions)

            # multiply the cost by the associated weight
            weight = weights[i]
            cost_for_state += weight * cost_for_cost_function
        costs.append({'state' : state, 'cost' : cost_for_state})

    # Find the minimum cost state.
    best_next_state = None
    min_cost = 9999999
    for i in range(len(possible_successor_states)):
        state = possible_successor_states[i]
        cost  = costs[i]
        if cost < min_cost:
            min_cost = cost
            best_next_state = state

    return best_next_state

    void Vehicle::update_state(map<int,vector < vector<int> > > predictions) {
    	/*
        Updates the "state" of the vehicle by assigning one of the
        following values to 'self.state':

        "KL" - Keep Lane
         - The vehicle will attempt to drive its target speed, unless there is
           traffic in front of it, in which case it will slow down.

        "LCL" or "LCR" - Lane Change Left / Right
         - The vehicle will IMMEDIATELY change lanes and then follow longitudinal
           behavior for the "KL" state in the new lane.

        "PLCL" or "PLCR" - Prepare for Lane Change Left / Right
         - The vehicle will find the nearest vehicle in the adjacent lane which is
           BEHIND itself and will adjust speed to try to get behind that vehicle.

        INPUTS
        - predictions
        A dictionary. The keys are ids of other vehicles and the values are arrays
        where each entry corresponds to the vehicle's predicted location at the
        corresponding timestep. The FIRST element in the array gives the vehicle's
        current position. Example (showing a car with id 3 moving at 2 m/s):

        {
          3 : [
            {"s" : 4, "lane": 0},
            {"s" : 6, "lane": 0},
            {"s" : 8, "lane": 0},
            {"s" : 10, "lane": 0},
          ]
        }

        */
        state = "KL"; // this is an example of how you change state.


    }

    void Vehicle::configure(vector<int> road_data) {
    	/*
        Called by simulator before simulation begins. Sets various
        parameters which will impact the ego vehicle.
        */
        target_speed = road_data[0];
        lanes_available = road_data[1];
        max_acceleration = road_data[2];
        goal_lane = road_data[3];
        goal_s = road_data[4];
    }

    string Vehicle::display() {

    	ostringstream oss;

    	oss << "s:    " << this->s << "\n";
        oss << "lane: " << this->lane << "\n";
        oss << "v:    " << this->v << "\n";
        oss << "a:    " << this->a << "\n";

        return oss.str();
    }

    void Vehicle::increment(int dt = 1) {

    	this->s += this->v * dt;
        this->v += this->a * dt;
    }

    vector<int> Vehicle::state_at(int t) {

    	/*
        Predicts state of vehicle in t seconds (assuming constant acceleration)
        */
        int s = this->s + this->v * t + this->a * t * t / 2;
        int v = this->v + this->a * t;
        return {this->lane, s, v, this->a};
    }

    bool Vehicle::collides_with(Vehicle other, int at_time) {

    	/*
        Simple collision detection.
        */
        vector<int> check1 = state_at(at_time);
        vector<int> check2 = other.state_at(at_time);
        return (check1[0] == check2[0]) && (abs(check1[1]-check2[1]) <= L);
    }

    Vehicle::collider Vehicle::will_collide_with(Vehicle other, int timesteps) {

    	Vehicle::collider collider_temp;
    	collider_temp.collision = false;
    	collider_temp.time = -1;

    	for (int t = 0; t < timesteps+1; t++)
    	{
          	if( collides_with(other, t) )
          	{
    			collider_temp.collision = true;
    			collider_temp.time = t;
            	return collider_temp;
        	}
    	}

    	return collider_temp;
    }

    void Vehicle::realize_state(map<int,vector < vector<int> > > predictions) {

    	/*
        Given a state, realize it by adjusting acceleration and lane.
        Note - lane changes happen instantaneously.
        */
        string state = this->state;
        if(state.compare("CS") == 0)
        {
        	realize_constant_speed();
        }
        else if(state.compare("KL") == 0)
        {
        	realize_keep_lane(predictions);
        }
        else if(state.compare("LCL") == 0)
        {
        	realize_lane_change(predictions, "L");
        }
        else if(state.compare("LCR") == 0)
        {
        	realize_lane_change(predictions, "R");
        }
        else if(state.compare("PLCL") == 0)
        {
        	realize_prep_lane_change(predictions, "L");
        }
        else if(state.compare("PLCR") == 0)
        {
        	realize_prep_lane_change(predictions, "R");
        }

    }

    void Vehicle::realize_constant_speed() {
    	a = 0;
    }

    int Vehicle::_max_accel_for_lane(map<int,vector<vector<int> > > predictions, int lane, int s) {

    	int delta_v_til_target = target_speed - v;
        int max_acc = min(max_acceleration, delta_v_til_target);

        map<int, vector<vector<int> > >::iterator it = predictions.begin();
        vector<vector<vector<int> > > in_front;
        while(it != predictions.end())
        {

        	int v_id = it->first;

            vector<vector<int> > v = it->second;

            if((v[0][0] == lane) && (v[0][1] > s))
            {
            	in_front.push_back(v);

            }
            it++;
        }

        if(in_front.size() > 0)
        {
        	int min_s = 1000;
        	vector<vector<int>> leading = {};
        	for(int i = 0; i < in_front.size(); i++)
        	{
        		if((in_front[i][0][1]-s) < min_s)
        		{
        			min_s = (in_front[i][0][1]-s);
        			leading = in_front[i];
        		}
        	}

        	int next_pos = leading[1][1];
        	int my_next = s + this->v;
        	int separation_next = next_pos - my_next;
        	int available_room = separation_next - preferred_buffer;
        	max_acc = min(max_acc, available_room);
        }

        return max_acc;

    }

    void Vehicle::realize_keep_lane(map<int,vector< vector<int> > > predictions) {
    	this->a = _max_accel_for_lane(predictions, this->lane, this->s);
    }

    void Vehicle::realize_lane_change(map<int,vector< vector<int> > > predictions, string direction) {
    	int delta = -1;
        if (direction.compare("L") == 0)
        {
        	delta = 1;
        }
        this->lane += delta;
        int lane = this->lane;
        int s = this->s;
        this->a = _max_accel_for_lane(predictions, lane, s);
    }

    void Vehicle::realize_prep_lane_change(map<int,vector<vector<int> > > predictions, string direction) {
    	int delta = -1;
        if (direction.compare("L") == 0)
        {
        	delta = 1;
        }
        int lane = this->lane + delta;

        map<int, vector<vector<int> > >::iterator it = predictions.begin();
        vector<vector<vector<int> > > at_behind;
        while(it != predictions.end())
        {
        	int v_id = it->first;
            vector<vector<int> > v = it->second;

            if((v[0][0] == lane) && (v[0][1] <= this->s))
            {
            	at_behind.push_back(v);

            }
            it++;
        }
        if(at_behind.size() > 0)
        {

        	int max_s = -1000;
        	vector<vector<int> > nearest_behind = {};
        	for(int i = 0; i < at_behind.size(); i++)
        	{
        		if((at_behind[i][0][1]) > max_s)
        		{
        			max_s = at_behind[i][0][1];
        			nearest_behind = at_behind[i];
        		}
        	}
        	int target_vel = nearest_behind[1][1] - nearest_behind[0][1];
        	int delta_v = this->v - target_vel;
        	int delta_s = this->s - nearest_behind[0][1];
        	if(delta_v != 0)
        	{

        		int time = -2 * delta_s/delta_v;
        		int a;
        		if (time == 0)
        		{
        			a = this->a;
        		}
        		else
        		{
        			a = delta_v/time;
        		}
        		if(a > this->max_acceleration)
        		{
        			a = this->max_acceleration;
        		}
        		if(a < -this->max_acceleration)
        		{
        			a = -this->max_acceleration;
        		}
        		this->a = a;
        	}
        	else
        	{
        		int my_min_acc = max(-this->max_acceleration,-delta_s);
        		this->a = my_min_acc;
        	}

        }

    }

    vector<vector<int> > Vehicle::generate_predictions(int horizon = 10) {

    	vector<vector<int> > predictions;
        for( int i = 0; i < horizon; i++)
        {
          vector<int> check1 = state_at(i);
          vector<int> lane_s = {check1[0], check1[1]};
          predictions.push_back(lane_s);
      	}
        return predictions;

    }

#endif
